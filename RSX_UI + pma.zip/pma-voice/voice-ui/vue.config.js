module.exports = {
    publicPath: './',
    productionSourceMap: true,
    filenameHashing: false,
    outputDir: "../ui",

}