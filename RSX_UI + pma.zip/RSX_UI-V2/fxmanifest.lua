fx_version 'cerulean'
games { 'gta5' }
author 'RaulGG'
client_script 'client.lua'

ui_page 'ui/index.html'

files {
    'ui/*.*',
}